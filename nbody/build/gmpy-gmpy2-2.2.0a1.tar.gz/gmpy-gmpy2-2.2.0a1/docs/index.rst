Welcome to gmpy2's documentation!
=================================

.. toctree::
   :maxdepth: 2

   intro
   overview
   mpz
   advmpz
   mpq
   contexts
   mpfr
   mpc
   cython
   conversion
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

.. * :ref:`modindex`
